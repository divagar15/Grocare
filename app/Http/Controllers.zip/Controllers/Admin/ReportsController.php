<?php namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\OrderDetails;
use App\Models\Products;
use App\Models\OrderProducts;
use App\Models\Couriers;
use App\Models\OrderBundleProducts;

use DB;
use Hash;
use Auth;
use Session;
use Config;

class ReportsController extends Controller {
	
	public function __construct(){
    	$this->orderStatus = Config::get('custom.orderStatus');
    	$this->countries = Config::get('custom.country');
    	$this->paymentType = Config::get('custom.paymentType');
    	$this->currencies = Config::get('custom.currency');
	}

	public function order(Request $request){
		$fromDate = date('Y-m-d');
		$toDate = date('Y-m-d');

		$type = $request->type;

		if($request->isMethod('post')){	
			$fromDate = date('Y-m-d',strtotime($request->from_date));
			$toDate = date('Y-m-d',strtotime($request->to_date));
			$type = $request->ptype;
		}

		if($type=='today') {
			$fromDate = date('Y-m-d');
			$toDate = date('Y-m-d');
		} else if($type=='month') {
			$fromDate = date('Y-m-01');
			$toDate = date('Y-m-d');
		} else if($type=='year') {
			$fromDate = date('Y-01-01');
			$toDate = date('Y-m-d');
		}

		 $fromTime = strtotime($fromDate);
	     $toTime = strtotime($toDate);
	     $datediff = $toTime - $fromTime;
	     $difference = abs(floor(($datediff/(60*60*24))))+1;

	     $chartResponse = array();

	     $orderDetails = OrderDetails::selectRaw('SUM(grand_total_inr) AS sales_amount,SUM(shipping_charge_inr) AS shipping_charge,count(id) AS total_orders,order_placed_date')->whereRaw('DATE(order_placed_date) between "'.$fromDate.'" AND "'.$toDate.'"')->where('delete_status',0)->whereNotNull('order_status')->whereNotIn('order_status',['7','8'])->groupBy(DB::raw('CAST(order_placed_date AS DATE)'))->get();

	    // return $orderDetails;

	     $totalSales = 0;
	     $salesAmount = 0;
	     $shippingCharge = 0;
	     $internationalOrders = 0;

	     if(isset($orderDetails) && !empty($orderDetails)) {
	     	foreach($orderDetails as $detail) {
	     		$day = date('d-M',strtotime($detail->order_placed_date));
	     		$oDate = date('Y-m-d',strtotime($detail->order_placed_date));

	     		$totalInternationOrders = OrderDetails::whereRaw('DATE(order_placed_date) = "'.$oDate.'"')->where('delete_status',0)->whereNotNull('order_status')->whereNotIn('order_status',['7','8'])->where('payment_type',3)->count();

	     		$internationalOrders += $totalInternationOrders;
	     		$sales = round($detail->sales_amount-$detail->shipping_charge);
	     		$shipping_charge = round($detail->shipping_charge);
	     		$orderPerDay = $detail->total_orders;


	     		$salesAmount += $sales;
	     		$shippingCharge += $shipping_charge;
	     		$totalSales += round($detail->sales_amount);

	     		$chartResponse[] = array('year'=>$day,'sales'=>$sales, 'orderPerDay'=>$orderPerDay,'totalInternationOrders'=>$totalInternationOrders);
	     	}
	     }

	     $averageSales = round($salesAmount/$difference);

	    //return $chartResponse;

/*

		

		$chartResponse[] = array('year'=>'01-Mar','sales'=>1500, 'shippingCharge'=>150);
		$chartResponse[] = array('year'=>'02-Mar','sales'=>12500, 'shippingCharge'=>1520);
		$chartResponse[] = array('year'=>'03-Mar','sales'=>12500, 'shippingCharge'=>1550);
		$chartResponse[] = array('year'=>'04-Mar','sales'=>14500, 'shippingCharge'=>2150);
		$chartResponse[] = array('year'=>'05-Mar','sales'=>19500, 'shippingCharge'=>3150);
		$chartResponse[] = array('year'=>'06-Mar','sales'=>15600, 'shippingCharge'=>5150);*/



		$response = json_encode($chartResponse);

		$orderPlaced=OrderDetails::select('id')->whereRaw('DATE(order_placed_date) between "'.$fromDate.'" AND "'.$toDate.'"')->where('delete_status',0)->whereNotIn('order_status',['7','8'])->count();

		$simpleProduct=OrderDetails::join('order_products as t2', 'order_details.oid', '=', 't2.oid')
					   ->selectRaw('SUM(t2.product_qty) AS qty')->whereRaw('DATE(order_details.order_placed_date) between "'.$fromDate.'" AND "'.$toDate.'"')
					   ->where('t2.product_type',1)->where('order_details.delete_status',0)->whereNotIn('order_details.order_status',['7','8'])
					   ->first();

		$bundleProduct=OrderDetails::join('order_bundle_products as t2', 'order_details.oid', '=', 't2.oid')
					   ->selectRaw('SUM(t2.product_qty) AS qty')->whereRaw('DATE(order_details.order_placed_date) between "'.$fromDate.'" AND "'.$toDate.'"')
					   ->where('order_details.delete_status',0)->whereNotIn('order_details.order_status',['7','8'])
					   ->first();

		$itemsPurchased = 0;

		if(count($simpleProduct)>0){
			if(!empty($simpleProduct->qty)) {
				$itemsPurchased=round($simpleProduct->qty);	
			}		
		}

		if(count($bundleProduct)>0){
			if(!empty($bundleProduct->qty)) {
				$itemsPurchased=round($bundleProduct->qty);	
			}		
		}

		return view('admin.reports.order')->with(array('fromDate'=>$fromDate,'toDate'=>$toDate,'response'=>$response,
			   'salesAmount'=>$salesAmount,'shippingCharge'=>$shippingCharge,'averageSales'=>$averageSales,
			   'orderPlaced'=>$orderPlaced,'itemsPurchased'=>$itemsPurchased));
	}


	public function customer(Request $request){
		$fromDate = date('Y-m-d');
		$toDate = date('Y-m-d');

		$type = $request->type;

		if($request->isMethod('post')){	
			$fromDate = date('Y-m-d',strtotime($request->from_date));
			$toDate = date('Y-m-d',strtotime($request->to_date));
			$type = $request->ptype;
		}

		if($type=='today') {
			$fromDate = date('Y-m-d');
			$toDate = date('Y-m-d');
		} else if($type=='month') {
			$fromDate = date('Y-m-01');
			$toDate = date('Y-m-d');
		} else if($type=='year') {
			$fromDate = date('Y-01-01');
			$toDate = date('Y-m-d');
		}

		 $fromTime = strtotime($fromDate);
	     $toTime = strtotime($toDate);
	     $datediff = $toTime - $fromTime;
	     $difference = abs(floor(($datediff/(60*60*24))))+1;

	     $newSignups = User::select('id')->whereRaw('DATE(created_at) between "'.$fromDate.'" AND "'.$toDate.'"')->where('user_type',2)->where('delete_status',0)->count();

	     $customerOrders = OrderDetails::select('id')->whereRaw('DATE(order_placed_date) between "'.$fromDate.'" AND "'.$toDate.'"')->where('fkcustomer_id','!=',0)->where('delete_status',0)->whereNotIn('order_status',['7','8'])->count();

	     $guestOrders = OrderDetails::select('id')->whereRaw('DATE(order_placed_date) between "'.$fromDate.'" AND "'.$toDate.'"')->where('fkcustomer_id','=',0)->where('delete_status',0)->whereNotIn('order_status',['7','8'])->count();

	     $orderDetailArray = array();

	     $customerOrdersDetail = OrderDetails::selectRaw('COUNT(id) AS cid,order_placed_date')->whereRaw('DATE(order_placed_date) between "'.$fromDate.'" AND "'.$toDate.'"')->where('fkcustomer_id','!=',0)->where('delete_status',0)->whereNotIn('order_status',['7','8'])->groupBy(DB::raw('DATE(order_placed_date)'))->orderBy('order_placed_date','ASC')->get();

	     if(isset($customerOrdersDetail) && !empty($customerOrdersDetail)) {
	     	foreach ($customerOrdersDetail as $customerDetail) {
	     		$day = date('d-M',strtotime($customerDetail->order_placed_date));
	     		$orderDetailArray[$day]['customer_order'] = $customerDetail->cid;
	     	}
	     }


	     $guestOrdersDetail = OrderDetails::selectRaw('COUNT(id) AS cid,order_placed_date')->whereRaw('DATE(order_placed_date) between "'.$fromDate.'" AND "'.$toDate.'"')->where('fkcustomer_id','=',0)->where('delete_status',0)->whereNotIn('order_status',['7','8'])->groupBy(DB::raw('DATE(order_placed_date)'))->orderBy('order_placed_date')->orderBy('order_placed_date','ASC')->get();

	     if(isset($guestOrdersDetail) && !empty($guestOrdersDetail)) {
	     	foreach ($guestOrdersDetail as $guestDetail) {
	     		$day = date('d-M',strtotime($guestDetail->order_placed_date));
	     		$orderDetailArray[$day]['guest_order'] = $guestDetail->cid;
	     	}
	     }


	    // return $orderDetailArray;

	    $chartResponse = array();

	    if(!empty($orderDetailArray)) {
	    	foreach ($orderDetailArray as $key => $value) {
	    		$custOrder = 0;
	    		$gueOrder = 0;
	    		if(isset($value['customer_order'])) {
	    			$custOrder = $value['customer_order'];
	    		}
	    		if(isset($value['guest_order'])) {
	    			$gueOrder = $value['guest_order'];
	    		}
	    		$chartResponse[] = array('year'=>$key,'customer_order'=>$custOrder, 'guest_order'=>$gueOrder);
	    	}
	    }

	   /* $chartResponse[] = array('year'=>'01-Mar','customer_order'=>1500, 'guest_order'=>150);
		$chartResponse[] = array('year'=>'02-Mar','customer_order'=>12500, 'guest_order'=>1520);
		$chartResponse[] = array('year'=>'03-Mar','customer_order'=>12500, 'guest_order'=>1550);*/


		$response = json_encode($chartResponse);

	     return view('admin.reports.customer')->with(array('fromDate'=>$fromDate,'toDate'=>$toDate,'customerOrders'=>$customerOrders,
	     	    'guestOrders'=>$guestOrders,'newSignups'=>$newSignups,'response'=>$response));

	 }

/*    public function reports(Request $request){
					
		$fromDate=date('Y-m-01');$from_date=date('01-m-Y');
		$toDate  =date('Y-m-t');$to_date=date('t-m-Y');
		if($request->isMethod('post')){				
			$from_date=$request->from_date;
			$to_date=$request->to_date;	
			if($from_date){
				$fromDate=date('Y-m-d',strtotime($from_date));
			}
			if($to_date){
				$toDate=date('Y-m-d',strtotime($to_date));
			}
			
		}
		
			$couriers = Couriers::where('delete_status',0)->get();
			$products = Products::where('delete_status',0)->get();			

			$orderDetails = OrderDetails::join('order_session as t2','order_details.oid','=','t2.id')
								->join('order_address as t3','order_details.id','=','t3.order_id')
								->select('order_details.id','order_details.invoice_no','order_details.grand_total_inr as grand_total','order_details.payment_type','order_details.shipping_charge',
									'order_details.fkcustomer_id','order_details.order_status','order_details.order_placed_date','t2.order_symbol',
									't3.billing_name','t3.billing_email','t3.billing_phone','t3.billing_address1',
									't3.billing_address2','t3.billing_state','t3.billing_city','t3.billing_country','t3.billing_zip','t3.shipping_name','t3.shipping_email','t3.shipping_phone','t3.shipping_address1',
									't3.shipping_address2','t3.shipping_state','t3.shipping_city','t3.shipping_country','t3.shipping_zip')
									->whereRaw('DATE(order_details.order_placed_date) between "'.$fromDate.'" AND "'.$toDate.'"');
									
			$orderDetails = $orderDetails->where('order_details.delete_status',0)->orderBy('order_details.id','DESC')->get();

        


        return view('admin.reports.reports')->with(array('orderDetails'=>$orderDetails, 'orderStatus'=>$this->orderStatus,
               'countries'=>$this->countries,'couriers'=>$couriers,'products'=>$products,'paymentType'=>$this->paymentType,'from_date'=>$from_date,'to_date'=>$to_date));
    
    }
    public function reportsExport(Request $request){
					
		$fromDate=date('Y-m-01');$from_date=date('01-m-Y');
		$toDate  =date('Y-m-t');$to_date=date('t-m-Y');
		if($request->isMethod('post')){				
			$from_date=$request->from_date;
			$to_date=$request->to_date;	
			if($from_date){
				$fromDate=date('Y-m-d',strtotime($from_date));
			}
			if($to_date){
				$toDate=date('Y-m-d',strtotime($to_date));
			}
			
		}
		
			$couriers = Couriers::where('delete_status',0)->get();
			$products = Products::where('delete_status',0)->get();			

			$orderDetails = OrderDetails::join('order_session as t2','order_details.oid','=','t2.id')
								->join('order_address as t3','order_details.id','=','t3.order_id')
								->select('order_details.id','order_details.invoice_no','order_details.grand_total_inr as grand_total','order_details.payment_type','order_details.shipping_charge',
									'order_details.fkcustomer_id','order_details.order_status','order_details.order_placed_date','t2.order_symbol',
									't3.billing_name','t3.billing_email','t3.billing_phone','t3.billing_address1',
									't3.billing_address2','t3.billing_state','t3.billing_city','t3.billing_country','t3.billing_zip','t3.shipping_name','t3.shipping_email','t3.shipping_phone','t3.shipping_address1',
									't3.shipping_address2','t3.shipping_state','t3.shipping_city','t3.shipping_country','t3.shipping_zip')
									->whereRaw('DATE(order_details.order_placed_date) between "'.$fromDate.'" AND "'.$toDate.'"');
									
			$orderDetails = $orderDetails->where('order_details.delete_status',0)->orderBy('order_details.id','DESC')->get();

        
    
    }*/
}