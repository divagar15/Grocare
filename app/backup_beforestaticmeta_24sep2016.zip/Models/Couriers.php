<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class Couriers extends Model {

	protected $table = 'couriers';
       
}
