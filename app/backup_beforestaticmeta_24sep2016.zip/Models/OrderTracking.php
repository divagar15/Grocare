<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class OrderTracking extends Model {

	protected $table = 'order_tracking';
       
}
