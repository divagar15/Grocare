<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class UserAddress extends Model {

	protected $table = 'user_address';
       
}