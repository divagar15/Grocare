<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class OrderSession extends Model {

	protected $table = 'order_session';
       
}
