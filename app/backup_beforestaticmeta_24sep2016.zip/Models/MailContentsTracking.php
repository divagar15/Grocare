<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class MailContentsTracking extends Model {

	protected $table = 'mail_content_tracking';

       
}
