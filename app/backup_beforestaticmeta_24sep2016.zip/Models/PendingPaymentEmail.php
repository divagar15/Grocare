<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class PendingPaymentEmail extends Model {

	protected $table = 'pending_payment_email';
       
}
