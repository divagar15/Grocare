<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class OrderDetails extends Model {

	protected $table = 'order_details';
       
}
