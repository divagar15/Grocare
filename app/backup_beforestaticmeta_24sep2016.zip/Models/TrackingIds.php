<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class TrackingIds extends Model {

	protected $table = 'tracking_ids';
       
}
