<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class BankDetails extends Model {

	protected $table = 'bank_details';
       
}
