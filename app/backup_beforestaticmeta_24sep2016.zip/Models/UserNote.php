<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class UserNote extends Model {

	protected $table = 'user_note';
       
}