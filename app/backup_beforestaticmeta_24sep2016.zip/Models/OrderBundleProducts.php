<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class OrderBundleProducts extends Model {

	protected $table = 'order_bundle_products';
       
}
