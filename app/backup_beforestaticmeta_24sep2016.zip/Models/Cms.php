<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Str;
class Cms extends Model {

	protected $table = 'cms';
       
}
