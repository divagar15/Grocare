<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class DiagnosisBlock extends Model {

	protected $table = 'diagnosis_blocks';

}