<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class OrderAddress extends Model {

	protected $table = 'order_address';
       
}
