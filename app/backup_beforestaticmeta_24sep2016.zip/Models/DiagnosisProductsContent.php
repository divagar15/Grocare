<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Str;
class DiagnosisProductsContent extends Model {

	protected $table = 'diagnosis_products_content';

       
}
