<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Str;
class ProductImages extends Model {

	protected $table = 'product_images';
       
}
