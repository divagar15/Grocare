@extends('front.layout.tpl')
@section('customCss')

<style type="text/css">
  #searchContainer {
    margin-top: 0px !important;
  }
  .feature-image{
	  min-height:200px;
	  max-height:200px;
  }

  .productGrid h3 {
    margin-top: 30px;
  }
</style>

@endsection

@section('content')

<div class="container pageStart" style="margin-top:130px;" id="productListing">

<div class="row">

  <div class="col-md-12" id="productTab">

    <div class="col-md-2 col-md-offset-4">

      <div class="active" id="products">
       <a href="{{URL::to('products')}}">
       <img src="{{URL::asset('public/front/images/icons/product-active.png')}}">
       <h3>PRODUCTS</h3>
       </a>
      </div>

    </div>

    <div class="col-md-2">

      <div class="inactive" id="medical-kit">
       <a href="{{URL::to('medicine-kit')}}">
        <img src="{{URL::asset('public/front/images/icons/medical-kit.png')}}">
        <h3>MEDICINE KIT</h3> 
       </a>
      </div>

    </div>


  </div>

</div>

  <div class="row" id="productsList">

    <div class="col-md-12 no-padding">
	<?php //var_dump($productList);?>
      @if((isset($productList)) && (count($productList)>0))


      @foreach($productList as $list)

      <div class="col-md-3">

          <div class="productGrid">
            <a href="{{URL::to('products/'.$list->product_slug)}}">
				<div class="feature-image">
                <img src="{{URL::asset('public/uploads/products/'.$list->id.'/'.$list->feature_image)}}" class="img-responsive" style="padding-top:15px;">
				</div>
                <h3>{{ucwords($list->name)}}</h3>
                <div class="description">
                  <p>{{ucfirst(substr($list->short_description,0,100))}}</p>
                </div>
                <div class="price">
                  <p><strong>{{$symbol}}&nbsp;@if(!empty($list->sales_price) && $list->sales_price!=0.00){{round($list->sales_price)}}@else{{round($list->regular_price)}}@endif</strong></p>
                </div>
              </a>
              <?php
                if(!empty($list->sales_price) && $list->sales_price!=0.00) {
                  $price =  $list->sales_price;
                } else {
                  $price =  $list->regular_price;
                }
              ?>
            <div class="cart">
              <p class="centralize"><a href="{{URL::to('add-to-cart')}}?product_type=1&product_course=0&product_id={{$list->id}}&product_price={{$price}}&product_qty=1&ordered_from=store">ADD TO CART</a></p>
            </div>
          </div>

      </div>

      @endforeach

      @else 

        <h5 style="text-align:center;">There are no products to display for your region </h5>

      @endif


    </div>

  </div>

</div>




@endsection

@section('customJs')


@endsection