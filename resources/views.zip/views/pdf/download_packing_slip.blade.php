<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title></title>
<!-- 	<link href='http://fonts.googleapis.com/css?family=Lato:700' rel='stylesheet' type='text/css'>
 -->
	<style>

		 body,td {
		 	font-family: 'Helvetica';
			font-size:15px;
		}		
				
		.page-break {
			page-break-after: always;
		}

	</style>
</head>
<body>
<div class="warper container-fluid"   style="width:95%;margin:0 auto; padding-top:-40px;">


            
            
                
                <div class="row" style="border-bottom:2px solid #000;">
				 <table width="100%">
				 
					<tr>
						<td style="vertical-align:top;margin:0px;text-align:right;"> 
							<span style="margin:0px;"><a href="" style="color:#333;font-size:14px !important;">Contents : @if($orderAddress->shipping_country=='IN') Herbal Medicines @else Dietary Supplements @endif</a></span>
							<br/>
						</td>
					</tr>					
					<tr>
						<td style="vertical-align:top;margin:0px;text-align:left;"> 
							<div class="col-md-6 shipping-address"   style="color:#222; font-size:12px;">
							 <p> To:
							 <strong> {{strtoupper($orderAddress->shipping_name)}}</strong></p>
							 <p style="padding-top:-10px;">  {{ucfirst($orderAddress->shipping_address1)}}, @if($orderAddress->shipping_address2!=''){{ucfirst($orderAddress->shipping_address2).","}}@endif</p>
							 <p style="padding-top:-10px;"> <strong> {{ucfirst($orderAddress->shipping_city)}} - {{$orderAddress->shipping_zip}}</strong>, {{ucfirst($orderAddress->shipping_state)}}</p>
							@if($orderAddress->shipping_country!='IN') <p style="padding-top:-10px;">  {{ucfirst($countries[$orderAddress->shipping_country])}}</p> @endif
							<p style="padding-top:-10px;"><i><strong>Phone : </strong> {{$orderAddress->billing_phone}}</i></p>
							  </div>
							  
                        </td>
                
              </tr>
					<tr>
						<td style="text-align:left;">
							<div class="col-md-6 grocare-address"   style="color:#111; font-size:10px; margin-top:-20px;">
								<p><a href="" style="color:#000:">From: </a>Grocare India - "Shivalik", Plot No. 14, Gangadham</p> 
								<p style="padding-top:-10px;">	Market Yard, Pune 411037</p>
								<p style="padding-top:-10px;">	Tel : 98221 00031 </p>
						       
							</div>
						</td>
					</tr>
					<tr>
						<td style="text-align:right;font-size:12px;"><p style="padding-top:-40px;"><strong>www.grocare.com</strong></p></td>
					</tr>
			  </table>
			  
                    </div>
                </div>
</body>
</html>